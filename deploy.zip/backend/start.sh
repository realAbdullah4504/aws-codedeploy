#!/bin/bash
python ./article_api.py 
# &
# python ./clock.py
